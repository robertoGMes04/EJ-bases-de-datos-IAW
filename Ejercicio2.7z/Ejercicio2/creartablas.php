<?php
 $servidor= "localhost";$usuario= "root"; $clave= ""; $bd="bdasignatura";
$conexion= new mysqli($servidor, $usuario, $clave, $bd);//CONECTA NUESTRO PROGRAMA CON PHP MY ADMIN
if ($conexion->connect_error)
{ 
     die("Error de conexión: " . $conexion->connect_error);
}
//EJECUCION DE SENTENCIAS
////
///
//↓↓↓↓↓↓↓Creacion de tablas↓↓↓↓↓↓↓↓↓

$sql = "CREATE TABLE ASIGNATURA (
CODIGO INT(12)  PRIMARY KEY,
NOMBRE VARCHAR(30) NOT NULL,
CREDITOS VARCHAR(30) )"
;

if ($conexion->query($sql) === TRUE)
{
     echo "Se creó la tabla de ASIGNATURA"; 
}
else 
{ 
     echo "Error al crear tabla";
}

$tablaalumno="CREATE TABLE ALUMNO(
    DNI INT(12)  PRIMARY KEY,
    NOMBRE VARCHAR(30)NOT NULL,
    APELLIDOS VARCHAR(30)NOT NULL,
    LOCALIDAD VARCHAR(50)NOT NULL,
    AÑO_DE_INICIO INT(4) NOT NULL,
    MODO_ACCESO VARCHAR(50)NOT NULL

    
)";
if ($conexion->query($tablaalumno) === TRUE)
{
     echo "Se creó la tabla de alumnos"; 
}
else 
{ 
     echo "Error al crear tabla";
}

$alumnoasignatura="CREATE TABLE ALUMNO_ASIGNATURA(
    CODIGO_ALUM_ASIG INT(12),
    DNI INT(12),
    CODIGO_ASIG INT(12),
    NOMBRE VARCHAR(30),
    FOREIGN KEY(DNI) REFERENCES ALUMNO(DNI),
    FOREIGN KEY(CODIGO_ASIG) REFERENCES ASIGNATURA(CODIGO),
    PRIMARY KEY(CODIGO_ALUM_ASIG)
)";







if ($conexion->query($alumnoasignatura) === TRUE)
{
     echo "Se creó la tabla de alumno_asignatura"; 
}
else 
{ 
     echo "Error al crear tabla";
}
/////↑↑↑↑↑↑creacion de tablas↑↑↑↑↑↑↑↑↑↑
///
//
//
//CIERRE DE CONEXION

$conexion->close(); 
?>