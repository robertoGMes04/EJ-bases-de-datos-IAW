<?php
$servidor="localhost" ; $usuario= "root";$clave= "";
$conexion= new mysqli($servidor, $usuario,$clave);//CONECTA NUESTRO PROGRAMA CON PHP MY ADMIN
if ($conexion->connect_error)
{
     die("Error de conexión: " . $conexion->connect_error);//si la conexion no funciona da un error
}
//EJECUCION DE SENTENCIAS
$sql = "CREATE DATABASE bdasignatura"; //Creamos la base de datos deseada
if ($conexion->query($sql) === TRUE) { echo "Base de datos creada"; }
else
{ echo "Error creando base de datos: " . $conexion->error;}//CIERRE DE CONEXION
$conexion->close(); 
?>